import React from 'react'; 
import Home from './components/HomePage/Home';
import Login from './components/LoginPage/Login'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css'; 

function App() {
  return (
   <Router>
    <>
      <div className="App">
        <Home />
      </div>
    </>
   </Router>
  );
}

export default App;
